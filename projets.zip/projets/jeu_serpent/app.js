// Variables du jeu
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const scoreDisplay = document.getElementById('score');
const startButton = document.getElementById('startBtn');

// Taille du canvas
const canvasWidth = 400;
const canvasHeight = 400;
canvas.width = canvasWidth;
canvas.height = canvasHeight;

// Variables du serpent
let snake = [{ x: 150, y: 150 }, { x: 140, y: 150 }, { x: 130, y: 150 }];
let direction = 'RIGHT';
let food = {};
let score = 0;
let gameInterval;

// Contrôles du serpent
document.addEventListener('keydown', (event) => {
    if (event.key === 'ArrowUp' && direction !== 'DOWN') direction = 'UP';
    if (event.key === 'ArrowDown' && direction !== 'UP') direction = 'DOWN';
    if (event.key === 'ArrowLeft' && direction !== 'RIGHT') direction = 'LEFT';
    if (event.key === 'ArrowRight' && direction !== 'LEFT') direction = 'RIGHT';
});

// Fonction pour dessiner le serpent et la nourriture
function drawGame() {
    ctx.clearRect(0, 0, canvas.width, canvas.height); // Effacer le canvas

    // Dessiner le serpent
    for (let i = 0; i < snake.length; i++) {
        ctx.fillStyle = i === 0 ? 'green' : 'lightgreen'; // Tête verte, corps vert clair
        ctx.fillRect(snake[i].x, snake[i].y, 10, 10);
    }

    // Dessiner la nourriture
    ctx.fillStyle = 'red';
    ctx.fillRect(food.x, food.y, 10, 10);

    // Mettre à jour le score
    scoreDisplay.textContent = score;
}

// Fonction pour déplacer le serpent
function moveSnake() {
    let head = { ...snake[0] };

    if (direction === 'UP') head.y -= 10;
    if (direction === 'DOWN') head.y += 10;
    if (direction === 'LEFT') head.x -= 10;
    if (direction === 'RIGHT') head.x += 10;

    snake.unshift(head); // Ajouter la nouvelle tête

    // Vérifier si le serpent mange la nourriture
    if (head.x === food.x && head.y === food.y) {
        score += 10;
        generateFood();
    } else {
        snake.pop(); // Retirer la dernière partie du serpent
    }

    // Vérifier les collisions avec le mur
    if (head.x < 0 || head.x >= canvasWidth || head.y < 0 || head.y >= canvasHeight) {
        gameOver();
    }

    // Vérifier les collisions avec le corps du serpent
    for (let i = 1; i < snake.length; i++) {
        if (head.x === snake[i].x && head.y === snake[i].y) {
            gameOver();
        }
    }
}

// Fonction pour générer la nourriture à un endroit aléatoire
function generateFood() {
    const foodX = Math.floor(Math.random() * (canvasWidth / 10)) * 10;
    const foodY = Math.floor(Math.random() * (canvasHeight / 10)) * 10;
    food = { x: foodX, y: foodY };
}

// Fonction de fin de jeu
function gameOver() {
    clearInterval(gameInterval);
    alert('Game Over! Votre score est ' + score);
    startButton.style.display = 'inline-block';
}

// Fonction de démarrage du jeu
function startGame() {
    snake = [{ x: 150, y: 150 }, { x: 140, y: 150 }, { x: 130, y: 150 }];
    direction = 'RIGHT';
    score = 0;
    scoreDisplay.textContent = score;
    generateFood();
    startButton.style.display = 'none';

    if (gameInterval) clearInterval(gameInterval);
    gameInterval = setInterval(() => {
        moveSnake();
        drawGame();
    }, 100);
}

// Bouton recommencer
startButton.addEventListener('click', startGame);

// Lancer le jeu au chargement de la page
startGame();
