// Tableau de citations incluant des citations sur le racisme, l'égalité et la justice
const quotes = [
    "La vie est ce que l'on en fait. Toujours l’aimer comme elle est. – Jean-Paul Sartre",
    "Le succès, c'est d'aller d'échec en échec sans perdre son enthousiasme. – Winston Churchill",
    "L'amour de la liberté est la première condition du bonheur. – Albert Schweitzer",
    "Il n'y a pas de chemin vers le bonheur. Le bonheur c'est le chemin. – Bouddha",
    "La seule façon de faire un excellent travail est d’aimer ce que vous faites. – Steve Jobs",
    "Le voyage de mille lieues commence par un pas. – Lao Tseu",
    "Visez la lune. Même si vous la ratez, vous atteindrez les étoiles. – W. Clement Stone",
    "L’éducation est l'arme la plus puissante qu'on puisse utiliser pour changer le monde. – Nelson Mandela",
    "Je ne joue pas pour les récompenses, je joue pour ma passion. – Neymar",
    "Le football ne se résume pas à gagner, il s'agit de créer un héritage et d’être respecté. – Neymar",
    "Tout ce que vous pouvez imaginer est réel. – Pablo Picasso",
    "La discipline est le pont entre les objectifs et l'accomplissement. – Jim Rohn",
    "Le courage, c’est de comprendre sa propre peur et d’y faire face. – Denzel Washington",
    "Les gagnants ne sont pas ceux qui ne tombent jamais, mais ceux qui se relèvent après chaque chute. – Denzel Washington",
    "La seule façon de faire un excellent travail est d'aimer ce que vous faites. – Steve Jobs",
    "L'humilité est la vraie clé du succès. – Samuel Eto'o (footballeur camerounais)",
    "Lorsque les lions se battent, ce sont les moutons qui paient le prix. – Proverbe africain",
    "L'unité est la clé du progrès. – Kwame Nkrumah (homme politique ghanéen)",
    "Ceux qui ne se battent pas pour la liberté, la perdent. – Patrice Lumumba (homme politique congolais)",
    "Rien n’est plus puissant qu’une idée dont l’heure est venue. – Amílcar Cabral (leader révolutionnaire africain)",
    
    // Citations sur le racisme et l'égalité
    "Je suis noir, et je suis fier de l'être, mais je ne veux pas être jugé par la couleur de ma peau. – Martin Luther King Jr.",
    "Le racisme n'est pas une opinion, c'est un crime. – Malcolm X",
    "L’ignorance est la racine de tous les préjugés. – Pierre Bayle",
    "L’égalité n’est pas un privilège, c’est un droit. – Nelson Mandela",
    "Le racisme est une barrière invisible que nous devons briser. – Maya Angelou",
    "Il n’y a pas de plus grand mal que l’intolérance. – Mahatma Gandhi",
    "La couleur de la peau ne définit pas qui nous sommes, c’est nos actions qui le font. – Barack Obama",
    "Ne me jugez pas à ma couleur, jugez-moi à mes actions. – Nelson Mandela",
    "Ce qui est essentiel dans la vie, c'est que tout le monde soit traité de la même manière, quel que soit leur passé ou leur couleur. – Serena Williams",
    "La haine est un fardeau trop lourd à porter. – Coretta Scott King",
    "Le racisme est l’ennemi de la paix. – Desmond Tutu",
    "L'égalité est un droit, pas un privilège. – Oprah Winfrey",
    "Si vous êtes neutre dans des situations d'injustice, vous avez choisi le camp de l'oppresseur. – Desmond Tutu"
];

// Fonction pour générer une citation aléatoire
function generateRandomQuote() {
    const randomIndex = Math.floor(Math.random() * quotes.length);
    const randomQuote = quotes[randomIndex];
    document.getElementById('quoteDisplay').textContent = randomQuote;
}

// Appeler la fonction pour afficher une citation dès le début
generateRandomQuote();
