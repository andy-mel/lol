<?php

    header('Location: Controleur/accueil.php');

?>