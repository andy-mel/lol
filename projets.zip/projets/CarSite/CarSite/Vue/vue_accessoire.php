<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>accessoire</title>
    <style>
        <?php
            include("../CSS/vue_accessoire.css");    
        ?>       
    </style>
  
</head>
<body>
    <center>
        <header>
            <center><p><h1>NOS ACCESSOIRES</h1></p></center>
        </header>
    </center>

    <?php
        require_once("../Modele/modele_accessoire.php");
        require_once("../Modele/modele_voiture.php");
        $donnees = images_accessoires();
        affichage($donnees);

    ?>
    <footer></footer>
</body>
</html>