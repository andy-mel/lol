<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>article</title>
    <style>
        <?php
            include("../CSS/presentation.css");        
        if(isset($_SESSION['admin']) AND $_SESSION['admin']==1)
        { ?>
        
        .images .aimg
        {
            display: inline-block;
            width: 80%;
            height: 100%;
            vertical-align: top;
        }

        .images .aimg img
        {
            width: 90%;
        }
        .images .delete
        {
            display: inline-block;
            width: 18%;
            vertical-align: top;
            text-align: center;
            padding-top: 7%;
            text-decoration: none;
            color: black;
        }

        .images .delete a{
            display: inline;
            text-decoration: none;
            color: black;
        }

        .images .delete a:hover
        {
            color: red;
        }
    @media (max-width: 1060px)
    {
      
        .images .aimg
        {
            display: inline-block;
            width: 90%;
            height: 100%;
            vertical-align: top;
        }
        .images .delete
        {
            display: inline-block;
            width: 20%;
            vertical-align: top;
            text-align: center;
            padding-top: 7%;
            text-decoration: none;
            color: black;
            position: relative;
            bottom: 80px;
            left: 84%;
        }
    }
        <?php
        }

        ?>
    </style>
    
</head>
<body>
<header id="header">
    <div>
        <b>ANDY MEL & COMPANY</b>
    </div>
    <div style="text-align: right;">
        <a href="../Controleur/recherche.php?id_article=<?php echo $_GET['id_article']; ?>&page=preArt"><span title="rechercher"><svg xmlns="http://www.w3.org/0000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16"><path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/></svg></span></a>
        <?php if(!isset($_SESSION['admin']) OR $_SESSION['admin']==0){ ?>
        <span onclick="connexion();" title="se connecter"><svg xmlns="http://www.w3.org/0000/svg" width="16" height="16" fill="currentColor" class="bi bi-person" viewBox="0 0 16 16"><path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0Zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4Zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10Z"/></svg></span>
        <?php } else { ?>
            <a href="../Controleur/ajout.php?page=preArt&id_article=<?php echo $_GET['id_article']; ?>"><span title="ajouter un élément"><svg xmlns="http://www.w3.org/0000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus" viewBox="0 0 16 16"><path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z"/></svg></span></a>
           <?php } ?>
        <span onclick="menu();" title="menu"><svg xmlns="http://www.w3.org/0000/svg" width="16" height="16" fill="currentColor" class="bi bi-three-dots-vertical" viewBox="0 0 16 16"><path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z"/></svg></span>
    </div>
</header>
    <article>
        <header>
            <?php
            if(isset($_SESSION['admin']) AND $_SESSION['admin']==1)
            { ?>
                <div id="headiv1"><?php echo htmlspecialchars($infos['nom']); ?></div>
                <div id="headiv2">
                    <a href="gestion.php?id_article=<?php echo $_GET['id_article']; ?>">
                        <span title="modifier">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil" viewBox="0 0 16 16">
                                <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207 11.207 2.5zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293l6.5-6.5zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325z"/>
                            </svg>
                        </span>
                    </a>
                    <span onclick="suppression();" title="supprimer l'article">
                        <?php include('../Fichiers/33874.svg'); ?>
                    </span>
                </div>
                
            <?php } else
            {
                echo htmlspecialchars($infos['nom']);
            }
            ?>
        </header>
        <section>
            <div class="img">
                <img src="<?php echo $lastPicture; ?>" alt="Photo de l'élément">
            </div>
            <div class="description">
                État : <?php echo $infos['etat']; ?><br /><br />
                <?php echo nl2br($infos['description']); ?>
            </div>
        </section>
        <section id="pic">

            <?php
                for($i = 0 ; $i < sizeof($allPictures) ; $i++)
                {
                    ?>
                    <div class="images"><a href="<?php echo $allPictures[$i]; ?>" class="aimg"><img src="<?php echo $allPictures[$i]; ?>" alt=""></a>
                    <?php if(isset($_SESSION['admin']) AND $_SESSION['admin']==1)
                    { ?>
                    <span class="delete">
                            <a href="../Controleur/presentation_article.php?delete=true&id_picture=<?php echo $pictures[$i]; ?>&id_article=<?php echo $_GET['id_article']; ?>" >
                            <?php include('../Fichiers/33874.svg'); ?>
                            </a></span>
                  <?php  }
                    ?>
                </div>
                    <?php
                }
                if(isset($_SESSION['admin']) AND $_SESSION['admin']==1)
                {?>
                    <span id = "plus" onclick = "newPicture();">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus-square" viewBox="0 0 16 16">
                            <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z"/>
                            <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z"/>
                        </svg>
                    </span>
                    <div id="blocNewPicture"></div>
<div id="newPicture">
<p><svg onclick="newPicture();" xmlns="http://www.w3.org/0000/svg" width="16" height="16" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16" ><path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/></svg></p>
    <form action="../Controleur/presentation_article.php?id_article=<?php echo $_GET['id_article']; ?>" method="post" enctype="multipart/form-data">
        <h2>Ajoutez une photo pour cet article</h2>
        <div class="inputbox">
            <span>Choisissez une image</span>
            <div class="btn">Choisir<input type="file" name="fichier" id="fichier" required accept=".jpg, .jpeg, .png, .bmp, .tiff, .svg" onchange="excuse()"></div>
            <input type="text" id="desole" style="margin-top: 20px;" readonly>
            <script>
                function excuse(){
                abcdefg = document.getElementById("fichier").value
                azerty = ""
                for(i = 12; i < abcdefg.length; i++){
                    azerty += abcdefg[i]
                }

                document.getElementById("desole").value = azerty
                }
            </script>
            <input type="hidden" name="id" value="<?php echo $_GET['id_article']; ?>">
        </div>
        <footer>
            <input type="submit" value="Soumettre" name="submit">
        </footer>
    </form>

</div>
              <?php  }
            ?>
        </section>
    </article>
    <div id="blocMenu"></div>
<div id="menu">
    <header><svg onclick="menu();" xmlns="http://www.w3.org/0000/svg" width="16" height="16" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16" ><path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/></svg></header>
    <div>
        <p>ANDY MEL & COMPANY</p>
        <a href="../Controleur/accueil.php">
            Accueil
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-house" viewBox="0 0 16 16">
                <path d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L2 8.207V13.5A1.5 1.5 0 0 0 3.5 15h9a1.5 1.5 0 0 0 1.5-1.5V8.207l.646.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5ZM13 7.207V13.5a.5.5 0 0 1-.5.5h-9a.5.5 0 0 1-.5-.5V7.207l5-5 5 5Z"/>
            </svg>  
        </a><hr>
        <a href="../Controleur/article.php?type=NOS VEHICULES">Ordinateurs</a>
        <a href="../Controleur/article.php?type=NOS ACCESSOIRES">Accessoires</a>
        <?php
        if(isset($_SESSION['admin']) AND $_SESSION['admin']==1)
        {
            echo "<hr><a href='../Controleur/gestion.php'>Articles en rupture de stock</a>";   
            echo "<a href='../Controleur/change_password.php'>Changer de mot de passe</a>";
            echo "<a href='../Controleur/new_admin.php'>Nouvel Administrateur</a>";
            echo "<form method=\"post\" action=\"../Controleur/accueil.php\"><span><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"currentColor\" class=\"bi bi-door-open\" viewBox=\"0 0 16 16\"><path d=\"M8.5 10c-.276 0-.5-.448-.5-1s.224-1 .5-1 .5.448.5 1-.224 1-.5 1z\"/><path d=\"M10.828.122A.5.5 0 0 1 11 .5V1h.5A1.5 1.5 0 0 1 13 2.5V15h1.5a.5.5 0 0 1 0 1h-13a.5.5 0 0 1 0-1H3V1.5a.5.5 0 0 1 .43-.495l7-1a.5.5 0 0 1 .398.117zM11.5 2H11v13h1V2.5a.5.5 0 0 0-.5-.5zM4 1.934V15h6V1.077l-6 .857z\"/></svg><input type=\"submit\" value=\" Se Deconnecter\" name=\"deconnect\"></span></form>";
        }
        ?>
    </div>
</div>
<div id="blocConnexion"></div>
<div id="connexion">
<p><svg onclick="connexion();" xmlns="http://www.w3.org/0000/svg" width="16" height="16" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16" ><path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/></svg></p>
    <form action="../Controleur/accueil.php" method="post">
        <h2><b>Connectez-vous en tant <br> qu'administrateur</b></h2>
        <div class="inputbox">
            <span>Entrez votre identifiant</span>
            <input type="text" name="id" id="id" placeholder="Entrez votre identifiant" required>
        </div>
        <div class="inputbox">
            <span>Entrez votre mot de passe</span>
            <input type="password" name="password" id="password" placeholder="Entrez votre mot de passe" required>
        </div>
        <footer>
            <input type="submit" value="Se Connecter">
        </footer>
        <?php
            if(isset($error) AND $error!=0)
            {
                echo "<div class=\"inputbox\" style=\"text-align: center; color: darkred;\">❌❌❌Identifiant ou mot de passe incorrect❌❌❌</div>";
            }
        ?>
    </form>
</div>


<footer style="text-align: center; padding: 1.5em; background-color: rgb(240,240,240);">
    <h2>Contactez-Nous</h2>
    <div>
        WhatsApp: 697426507/627423165 <br><br>
        Email: <a href="mailto:andymel283@gmail.com" style="text-decoration: none; color: black;">andymel283@gmail.com</a>
    </div>
</footer>

<?php
    if($_SESSION['admin'] == 1 AND isset($_SESSION['admin']))
    {
        ?>
        <div id="suppression">
                    <form action="../Controleur/presentation_article.php?id_article=<?php echo $_GET['id_article']; ?>" method="post">
                        <h2>Êtes-Vous sûr de vouloir supprimer definitivement cet article ?</h2>
                        <footer> 
                            <span onclick="suppression();">Annuler</span>
                            <input type="submit" value="Supprimer" name="suppression">
                        </footer>
                    </form>
                </div>
        <?php
    }
?>


</body>
<script>
    function menu()
    {
        if(document.getElementById("menu").style.opacity==0 && document.getElementById("blocMenu").style.opacity==0 )
        {
            document.getElementById("menu").style.opacity=1;
            document.getElementById("blocMenu").style.opacity=1;
            document.getElementById("menu").style.visibility="visible";
            document.getElementById("blocMenu").style.visibility="visible";
            document.getElementById("menu").style.transition="1s ease";
            document.getElementById("blocMenu").style.transition="1s ease";
        }else
        {
            document.getElementById("menu").style.opacity=0;
            document.getElementById("blocMenu").style.opacity=0;
            document.getElementById("menu").style.visibility="hidden";
            document.getElementById("blocMenu").style.visibility="hidden";
            document.getElementById("menu").style.transition="1s ease";
            document.getElementById("blocMenu").style.transition="1s ease";
        }
    }
    function connexion()
    {
        if(document.getElementById("blocConnexion").style.visibility=="hidden" && document.getElementById("connexion").style.visibility=="hidden")
        {
            document.getElementById("connexion").style.visibility="visible";
            document.getElementById("blocConnexion").style.visibility="visible";
            document.getElementById("connexion").style.opacity=1;
            document.getElementById("blocConnexion").style.opacity=1;
            document.getElementById("connexion").style.transition="1s ease";
            document.getElementById("blocConnexion").style.transition="1s ease";
            
        }else
        {
            document.getElementById("connexion").style.visibility="hidden";
            document.getElementById("blocConnexion").style.visibility="hidden";
            document.getElementById("connexion").style.opacity=0;
            document.getElementById("blocConnexion").style.opacity=0;
            document.getElementById("connexion").style.transition="1s ease";
            document.getElementById("blocConnexion").style.transition="1s ease";
        }
    }
    function newPicture()
    {
        if(document.getElementById("blocNewPicture").style.visibility=="hidden" && document.getElementById("newPicture").style.visibility=="hidden")
        {
            document.getElementById("newPicture").style.visibility="visible";
            document.getElementById("blocNewPicture").style.visibility="visible";
            document.getElementById("newPicture").style.opacity=1;
            document.getElementById("blocNewPicture").style.opacity=1;
            document.getElementById("newPicture").style.transition="1s ease";
            document.getElementById("blocNewPicture").style.transition="1s ease";
            
        }else
        {
            document.getElementById("newPicture").style.visibility="hidden";
            document.getElementById("blocNewPicture").style.visibility="hidden";
            document.getElementById("newPicture").style.opacity=0;
            document.getElementById("blocNewPicture").style.opacity=0;
            document.getElementById("newPicture").style.transition="1s ease";
            document.getElementById("blocNewPicture").style.transition="1s ease";
        }
    }

    function suppression()
    {
        if(document.getElementById("blocNewPicture").style.visibility=="hidden" && document.getElementById("suppression").style.visibility=="hidden")
        {
            document.getElementById("suppression").style.visibility="visible";
            document.getElementById("blocNewPicture").style.visibility="visible";
            document.getElementById("suppression").style.opacity=1;
            document.getElementById("blocNewPicture").style.opacity=1;
            document.getElementById("suppression").style.transition="1s ease";
            document.getElementById("blocNewPicture").style.transition="1s ease";
            
        }else
        {
            document.getElementById("suppression").style.visibility="hidden";
            document.getElementById("blocNewPicture").style.visibility="hidden";
            document.getElementById("suppression").style.opacity=0;
            document.getElementById("blocNewPicture").style.opacity=0;
            document.getElementById("suppression").style.transition="1s ease";
            document.getElementById("blocNewPicture").style.transition="1s ease";
        }
    }
</script>
</html>