<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        <?php
            if(isset($_GET['page']) AND $_GET['page']=="resRec")
            {
                $action = "../Controleur/resultatRecherche.php?motsCle=".$_GET['motsCle'];
            }elseif(isset($_GET['page']) AND $_GET['page']=="preArt")
            {
                $action = "../Controleur/presentation_article.php?id_article=".$_GET['id_article'];
            }elseif(isset($_GET['page']) AND $_GET['page'] == 'gestion')
            {
                $action = "../Controleur/gestion.php";
            } else
            {
                $action = "../Controleur/accueil.php";
            }
            include_once('../CSS/recherche.css');
        ?>
    </style>
    <title>Rechercher</title>
</head>
<body>
    <article>
        <header>
            <a href=<?php echo $action; ?>>
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-lg" viewBox="0 0 16 16">
                    <path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"/>
                </svg>
            </a>
        </header>
        <h2>
            Besoin d'aide ?
        </h2>
        <form class="search" action="../Controleur/recherche.php<?php if(isset($_GET['page']) AND $_GET['page']=="gestion"){echo "?page=gestion";}?>" method="post">
            <input type="search" name="search" id="search" required>
            <input type="submit" value="🔎">
        </form>
        <div id="cache">
            <?php
            for($i = 0; $i < sizeof($five) ; $i++)
            {
                echo "<span class=\"box\">".$five[$i]."</span>";
            }

            ?>
        </div>
    </article>
    <script>
        function hide(e){
            t=e.target;
            if(t.tagName == "SPAN")
            {
                document.getElementById('search').value = t.innerHTML;
            }
            
        }

        ul=document.getElementById('cache');
        ul.addEventListener('click',hide,false);
        
    </script>
</body>
</html>