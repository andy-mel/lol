<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ordinateur</title>
    <style>
        <?php
            include("../CSS/vue_accessoire.css");    
        ?>       
    </style>
  
</head>
<body>
    <header>
        <center><p><h1>NOS Ordinateurs</h1></p></center>
    </header>
    <?php
        require_once("../Modele/modele_voiture.php");
        require_once("../Modele/modele_accessoire.php");
        $donnees = images_voitures();
        affichage($donnees);

    ?>
</body>
</html>