<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style><?php include_once('../CSS/ajout.css'); ?></style>
    <title>Ajouter un article</title>
</head>
<body>
    <?php
    if(isset($_GET['page']) AND $_GET['page']=="resRec")
    {
        $action = "../Controleur/resultatRecherche.php?motsCle=".$_GET['motsCle'];
        $lien = "?page=resRec&motsCle=".$_GET['motsCle'];
    }elseif(isset($_GET['page']) AND $_GET['page']=="preArt")
    {
        $action = "../Controleur/presentation_article.php?id_article=".$_GET['id_article'];
        $lien = "?page=preArt&id_article=".$_GET['id_article'];
    }elseif(isset($_GET['page']) AND $_GET['page'] == 'gestion')
    {
        $action = "../Controleur/gestion.php";
        $lien = "";
    } else
    {
        $action = "../Controleur/accueil.php";
        $lien = "";
    }
    if(isset($etape))
    {
        if($etape == 1)
        {
            ?>
            <article>
                <header><a href="<?php echo $action; ?>"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-lg" viewBox="0 0 16 16"><path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"/></svg></a></header>
                <form action="../Controleur/ajout.php<?php echo $lien; ?>" method="post">
                    <h2>Ajoutez <?php if($type == "voiture"){ echo "un nouvel Ordinateur";} else { echo "un nouvel accessoire d'ordinateur";} ?></h2>
                    <div class="inputbox">
                        <span>Entrez son nom</span>
                        <input type="text" name="nom" id="nom" required placeholder="Entrez un nom">
                    </div>
                    <div class="inputbox">
                        <span>Entrez une description</span>
                        <textarea name="description" id="description" cols="30" rows="5" placeholder="description ..."></textarea>
                    </div>
                    <footer>
                        <input type="submit" value="Précédent" name="submit">
                        <input type="submit" value="Continuer" name="submit">
                        <input type="hidden" name="type" value="<?php echo $type; ?>">
                        <input type="hidden" name="etat" value="<?php echo $etat; ?>">
                        <input type="hidden" name="statut" value="<?php echo $statut; ?>">
                    </footer>
                </form>
            </article>
            <?php
        }elseif($etape == 2)
        { ?>
             <article>
                <header><a href="<?php echo $action; ?>"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-lg" viewBox="0 0 16 16"><path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"/></svg></a></header>
                <form action="../Controleur/ajout.php<?php echo $lien; ?>" method="post" enctype="multipart/form-data">
                    <h2>Ajoutez une photo de votre <?php echo htmlspecialchars($nom); ?></h2>
                    <div class="inputbox">
                        <span>Entrez son chemin d'accès</span>
                        <input type="file" name="fichier" id="fichier" required accept=".jpg, .jpeg, .png, .bmp, .tiff, .svg">
                        
                    </div>
                    <footer>
                        <input type="submit" value="Précédent" name="submit">
                        <input type="submit" value="Terminer" name="submit">
                        <input type="hidden" name="type" value="<?php echo $type; ?>">
                        <input type="hidden" name="nom" value="<?php echo htmlspecialchars($nom); ?>">
                        <input type="hidden" name="etat" value="<?php echo $etat; ?>">
                        <input type="hidden" name="statut" value="<?php echo $statut; ?>">
                        <textarea name="description" cols="30" rows="0"><?php echo nl2br(htmlspecialchars($description)); ?></textarea>
                    </footer>
                </form>
            </article>
      <?php  } else
      { ?>
            <article>
                <header><a href="<?php echo $action; ?>"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-lg" viewBox="0 0 16 16"><path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"/></svg></a></header>
                <form action="../Controleur/ajout.php<?php echo $lien; ?>" method="post">
                    <h2>Ajoutez un article</h2>
                    <div class="inputbox">
                        <span>Choisissez son type</span>
                        <select name="type" required>
                            <option value="voiture">Ordinateur</option>
                            <option value="accessoire">Accessoire</option>
                        </select>
                        <div class="inputbox">
                        <span>Choisissez son état</span>
                        <select name="etat" required>
                            <option value="neuf">Neuf</option>
                            <option value="occasion">Occasion</option>
                        </select>
                    </div>
                    <div class="inputbox">
                        <span>Choisissez son statut</span>
                        <select name="statut" required>
                            <option value="present">Disponible</option>
                            <option value="absent">En rupture de stock</option>
                        </select>
                    </div>
                        
                    </div>
                    <footer>
                        <input type="submit" value="Continuer" name="submit">
                    </footer>
                </form>
            </article>
     <?php }
    }else{ ?>
        <article>
            <header><a href="<?php echo $action; ?>"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-lg" viewBox="0 0 16 16"><path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"/></svg></a></header>
                <form action="../Controleur/ajout.php<?php echo $lien; ?>" method="post">
                    <h2>Ajoutez un article</h2>
                    <div class="inputbox">
                        <span>Choisissez son type</span>
                        <select name="type" required>
                            <option value="voiture">Ordinateur</option>
                            <option value="accessoire">Accessoire</option>
                        </select>
                        
                    </div>
                    <div class="inputbox">
                        <span>Choisissez son état</span>
                        <select name="etat" required>
                            <option value="neuf">Neuf</option>
                            <option value="occasion">Occasion</option>
                        </select>
                    </div>
                    <div class="inputbox">
                        <span>Choisissez son statut</span>
                        <select name="statut" required>
                            <option value="present">Disponible</option>
                            <option value="absent">En rupture de stock</option>
                        </select>
                    </div>
                    <footer>
                        <input type="submit" value="Continuer" name="submit">
                    </footer>
                </form>
            </article>
 <?php   }
    ?>
    
</body>
</html>