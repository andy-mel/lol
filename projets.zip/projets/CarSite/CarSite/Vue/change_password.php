<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>change</title>
    <style>
    <?php
        include_once('../CSS/change_password.css');
    ?>        
    </style>
</head>
<body>
    <?php
        if(isset($error)){
            if($error == "password_different"){
                    echo "<script>alert('ECHEC DE L OPERATION: verifier si les valeurs entrées sont correctes');</script>";   
                }
            elseif($error == "password_false"){
                    echo "<script>alert('ECHEC DE L OPERATION: le mot de passe que vous avez entré est incorrecte');</script>";  
            }
            elseif($error == "id_existant"){
                echo "<script>alert('ECHEC DE L OPERATION: identifiant existant');</script>";
            }
        }
        if($etape == 1){ 
            ?>
            <article>
            <header><a href="../Controleur/accueil.php"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-lg" viewBox="0 0 16 16"><path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"/></svg></a></header>
            <form action="../Controleur/change_password.php" method="post">
                <div class="inputbox">
                    <span>entrer votre identifiant</span>
                    <input type="text" name="id" placeholder="entrer votre identifiant" required>
                    <span>entrer votre mot de passe</span>
                    <input type="password" name="pass" placeholder="entrer votre mot de passe" required>
                </div>
                <footer>    
                    <input type="submit" value="valider">                   
                </footer>
            </form>
            </article>
        <?php
        }
        elseif($etape == 2){
            ?>
                <article>
                    <header><a href="../Controleur/accueil.php"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-lg" viewBox="0 0 16 16"><path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"/></svg></a></header>
                    <form action="../Controleur/change_password.php" method="post">
                    <center><h1><i>QU'AVEZ-VOUS BESOIN DE MODIFIER🔧</i></h1></center>
                        <div class="inputbox">
                            <select name="type" id="type">
                                <option value="mot de passe">mot de passe</option>
                                <option value="identifiant">identifiant</option>
                            </select>
                            <input type="hidden" name="id" value='<?php echo $id; ?>'>
                            <footer>
                                <input type="submit" value="continuer">
                            </footer>
                        </div>
                    </form>
                </article>
            <?php
        }
        elseif($etape == 3){
            if(isset($type)){
                if($type == "mot de passe"){
            ?>
            <article>
            <header><a href="../Controleur/accueil.php"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-lg" viewBox="0 0 16 16"><path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"/></svg></a></header>
            <form action="../Controleur/change_password.php" method="post">
                <div class="inputbox">
                    <span>entrer le nouveau mot de passe</span>
                    <input type="password" name="new_password1" value="aucun" placeholder="entrer le nouveau mot de passe" onkeyup="valider()" id="pass1" required><br><br><br>
                    <span>êtes vous sur de cela</span>
                    <input type="password" name="new_password2" value="aucun" placeholder="entrer de nouveau le mot de passe" onkeyup="valider()" id="pass2" required><br>
                    <input type="hidden" name="hidden" value="<?php echo $type; ?>">
                    <input type="hidden" name="id" value='<?php echo $id; ?>'>
                </div>       
                <footer>  
                    <input type="submit" value="back" name='submit'><input type="submit" value="valider" id="submit" name="submit" style="opacity: 0.4;">              
                </footer>
            </form>
            </article>
            <script>
                function valider(){
                    a = document.getElementById("pass1").value;
                    b = document.getElementById("pass2").value;
                    if(a == b && a != ""){
                        document.getElementById("submit").style.opacity = 1;
                    }else{
                        document.getElementById("submit").style.opacity = 0.4;
                    }
                }
            </script>
            <?php                    
                }
                else{
                    ?>
                    <article>
                    <header><a href="../Controleur/accueil.php"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-lg" viewBox="0 0 16 16"><path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"/></svg></a></header>
                    <form action="../Controleur/change_password.php" method="post">
                        <div class="inputbox">
                            <span>entrer le nouvel identifiant</span>
                            <input type="password" name="new_id1" value="aucun" placeholder="entrer le nouvel identifiant" onkeyup="valider()" id="pass1" required><br><br><br>
                            <span>êtes vous sur de cela</span>
                            <input type="password" name="new_id2" value="aucun" placeholder="entrer de nouveau le nouvel identifiant" onkeyup="valider()" id="pass2" required><br>
                            <input type="hidden" name="hidden" value="<?php echo $type; ?>">
                            <input type="hidden" name="id" value='<?php echo $id; ?>'>
                        </div>       
                        <footer>  
                            <input type="submit" value="back" name='submit'><input type="submit" value="valider" id="submit" name="submit" style="opacity: 0.4;">                
                        </footer>
                    </form>
                    </article>
                    <script>
                        function valider(){
                            a = document.getElementById("pass1").value;
                            b = document.getElementById("pass2").value;
                            if(a == b && a != ""){
                                document.getElementById("submit").style.opacity = 1;
                            }else{
                                document.getElementById("submit").style.opacity = 0.4;
                            }
                        }
                    </script>
                <?php  
                }
            }else{
                header("location: ../Controleur/change_password.php");
            }

        }
        elseif($etape == 4){
            ?>
                <article>
                <header><a href="../Controleur/accueil.php"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-lg" viewBox="0 0 16 16"><path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"/></svg></a></header>
                <form action="../Controleur/change_password.php" method="post">
                <center><h1><i>L'OPERATION S'EST DEROULE AVEC SUCCES✅</i></h1></center>
                <input type="hidden" name="hidden" value="<?php echo $type; ?>">
                <input type="hidden" name="id" value='<?php echo $id; ?>'>
                <footer><input type="submit" value="back" name='soumettre'><input type="submit" value="terminer" name="soumettre" ></footer>
                </form>
                </article>
            <?php
        }
    ?>
</body>
</html>


