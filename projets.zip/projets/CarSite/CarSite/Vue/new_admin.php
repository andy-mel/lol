<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>nouvel administrateur</title>
    <style>
    <?php
        include_once('../CSS/change_password.css');
    ?>        
    </style>
</head>
<body>
<?php
    if(isset($error)){
        if($error == "password_false"){
            echo "<script>alert('ECHEC DE L OPERATION: le mot de passe que vous avez entré est incorrecte');</script>";  
        }
        elseif($error == "id_existant"){
            echo "<script>alert('ECHEC DE L OPERATION: identifiant existant');</script>";  
    }
    }
    if($etape == 1){
?>
        <article>
            <header><a href="../Controleur/accueil.php"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-lg" viewBox="0 0 16 16"><path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"/></svg></a></header>
            <form action="../Controleur/new_admin.php" method="post">
                <div class="inputbox">
                    <span>entrer votre mot de passe</span>
                    <input type="password" name="pass" placeholder="entrer votre mot de passe" required>
                </div>
                <footer>    
                    <input type="submit" value="valider">                   
                </footer>
            </form>
        </article>
<?php
    }
    elseif ($etape == 2) {
    ?>
        <article>
            <header><a href="../Controleur/accueil.php"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-lg" viewBox="0 0 16 16"><path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"/></svg></a></header>
            <form action="../Controleur/new_admin.php" method="post">
                <div class="inputbox">
                    <span>definissez in identifiant</span>
                    <input type="text" name="id" placeholder="entrer l'identifiant du nouvel administrateur" required><br><br><br>
                    <span>definisez un mot de passe</span>
                    <input type="password" name="password" placeholder="definissez un mot de passe" required><br>
                </div>       
                <footer>
                    <input type="reset" value="supprimer">
                    <input type="submit" value="continuer">              
                </footer>
            </form>
        </article>
    <?php
    }
    elseif ($etape == 3) {
        ?>
            <article>
                <header><a href="../Controleur/accueil.php"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-lg" viewBox="0 0 16 16"><path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"/></svg></a></header>
                <form action="../Controleur/new_admin.php" method="post">
                    <center><h1><i>confirmer la creation d'un nouvel administrateur</i></h1></center>
                    <span class="content"><?php echo $id; ?></span><br><br>
                    <span class="content"><?php echo $password; ?></span>
                    <div class="inputbox">
                    <input type="hidden" value="<?php echo $id; ?>" name="hidden_id">
                    <input type="hidden" value="<?php echo $password; ?>" name="hidden_password">
                    </div>       
                    <footer>
                        <input type="submit" value="back" name="soumettre">
                        <input type="submit" value="valider" name="soumettre">              
                    </footer>
                </form>
            </article>
        <?php
        }
        elseif ($etape == 4) {
            ?>
                <article>
                <header><a href="../Controleur/accueil.php"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-lg" viewBox="0 0 16 16"><path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"/></svg></a></header>
                <form action="../Controleur/new_admin.php" method="post">
                <center><h1><i>L'OPERATION S'EST DEROULE AVEC SUCCES✅</i></h1></center>
                <footer><input type="submit" value="back" name='submit'><input type="submit" value="terminer" name="submit" ></footer>
                </form>
                </article>
            <?php
            }
?> 
</body>
</html>