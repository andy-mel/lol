<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="carsite, car site, site de vente de voiture, accessoires de voiture, voitures, bolide, site voiture, vente de voiture, cameroun, voitures au cameroun,voiture , "/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/accueil.css">
    <style>
         #voiture
        {
            background: url('../Images/<?php echo $voiture; ?>') no-repeat center center;
            background-size: cover;
            height: 500px;
            text-align: center;

        }
    #accessoire
        {
            background: url('../Images/<?php echo $accessoire; ?>') no-repeat center center;
            background-size: cover;
            height: 500px;
            text-align: center;

        }
    <?php include_once('../CSS/accueil.css');
        if(isset($error) AND $error!=0)
        {
            ?>
            #blocConnexion
                {
                    opacity: 1;
                    visibility: visible;
                }
                #connexion
                {
                    opacity: 1;
                    visibility: visible;
                }
            <?php
        }
    
    ?>
    
   
</style>
    <title>Accueil</title>
</head>
<body>
<header>
    <div>
        <b>ANDY MEL & COMPANY</b>
    </div>
    <div style="text-align: right;">
        <a href="../Controleur/recherche.php"><span title="rechercher"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16"><path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/></svg></span></a>
        <?php if(!isset($_SESSION['admin']) OR $_SESSION['admin']==0){ ?>
        <span onclick="connexion();" title="se connecter"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person" viewBox="0 0 16 16"><path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0Zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4Zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10Z"/></svg></span>
        <?php } else { ?>
            <a href="../Controleur/ajout.php"><span title="ajouter un élément"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus" viewBox="0 0 16 16"><path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z"/></svg></span></a>
           <?php } ?>
        <span onclick="menu();" title="menu"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-three-dots-vertical" viewBox="0 0 16 16"><path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z"/></svg></span>
    </div>
</header>
<article>
    <div id="artdiv1">
        <h2><?php echo htmlspecialchars($best['nom']); ?></h2>
        <p><?php echo nl2br($best['description']);?></p>
        <p style="height: 75px;"><a href="presentation_article.php?id_article=<?php echo $best['id']; ?>">En savoir plus</a></p>
    </div>
    <div><img id="img" src="../Images/<?php echo $bestImages[0];?>"></div>
</article>
<section>
    <div id="secdiv">Les choix de ce mois</div>
    <div id="section">
        <div class="section1" style="background-color: rgba(240, 240, 240, 1);">
            <img src="../Images/<?php echo getImage($section[0])?>" id="secimg1">
            <br><span><?php echo getName($section[0]) ?></span>
        </div>
        <div class="section1">
            <div class="section2">
                <div>
                    <img src="../Images/<?php echo getImage($section[1])?>" id="secimg2">
                    <br><span><?php echo getName($section[1]) ?></span>
                </div>
                <div>
                    <img src="../Images/<?php echo getImage($section[2])?>" id="secimg3">
                    <br><span><?php echo getName($section[2]) ?></span>
                </div>
            </div>
            <div class="section2">
                <div>
                    <img src="../Images/<?php echo getImage($section[3])?>" id="secimg4">
                    <br><span><?php echo getName($section[3]) ?></span>
                </div>
                <div>
                    <img src="../Images/<?php echo getImage($section[4])?>" id="secimg5">
                    <br><span><?php echo getName($section[4]) ?></span>
                </div>
            </div>
        </div>
    </div>
</section>
<div id="voiture">
    <header>Ordinateurs</header>
    <footer>
        <p><?php echo $nomVoiture;?></p>
        <p><a href="../Controleur/article.php?type=NOS VEHICULES">Voir tout</a></p>
    </footer>
</div>
<div id="accessoire">
    <header>Accessoires</header>
    <footer>
        <p><?php echo $nomAccessoire;?></p>
        <p><a href="../Controleur/article.php?type=NOS ACCESSOIRES">Voir tout</a></p>
    </footer>
</div>
<footer style="text-align: center; padding: 1.5em; background-color: rgb(240,240,240);">
    <h2>Contactez-Nous</h2>
    <div>
        WhatsApp: 697426507/627423165 <br><br>
        Email: <a href="mailto:andymel283@gmail.com" style="text-decoration: none; color: black;">andymel283@gmail.com</a>
    </div>
</footer>
<div id="blocMenu"></div>
<div id="menu">
    <header><svg onclick="menu();" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16" ><path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/></svg></header>
    <div>
        <p>ANDY MEL & COMPANY</p>
        <a href="../Controleur/recherche.php">Rechercher 🔎</a><hr>
        <a href="../Controleur/article.php?type=NOS VEHICULES">Ordinateurs</a>
        <a href="../Controleur/article.php?type=NOS ACCESSOIRES">Accessoires</a>
        <?php
        if(isset($_SESSION['admin']) AND $_SESSION['admin']==1)
        {
            echo "<hr><a href='../Controleur/gestion.php'>Articles en rupture de stock</a>";   
            echo "<a href='../Controleur/change_password.php'>Changer de mot de passe</a>";
            echo "<a href='../Controleur/new_admin.php'>Nouvel Administrateur</a>";
            echo "<form method=\"post\" action=\"../Controleur/accueil.php\"><span><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"currentColor\" class=\"bi bi-door-open\" viewBox=\"0 0 16 16\"><path d=\"M8.5 10c-.276 0-.5-.448-.5-1s.224-1 .5-1 .5.448.5 1-.224 1-.5 1z\"/><path d=\"M10.828.122A.5.5 0 0 1 11 .5V1h.5A1.5 1.5 0 0 1 13 2.5V15h1.5a.5.5 0 0 1 0 1h-13a.5.5 0 0 1 0-1H3V1.5a.5.5 0 0 1 .43-.495l7-1a.5.5 0 0 1 .398.117zM11.5 2H11v13h1V2.5a.5.5 0 0 0-.5-.5zM4 1.934V15h6V1.077l-6 .857z\"/></svg><input type=\"submit\" value=\" Se Deconnecter\" name=\"deconnect\"></span></form>";
        }
        ?>
    </div>
</div>
<div id="blocConnexion"></div>
<div id="connexion">
<p><svg onclick="connexion();" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16" ><path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/></svg></p>
    <form action="../Controleur/accueil.php" method="post">
        <h2><b>Connectez-vous en tant <br> qu'administrateur</b></h2>
        <div class="inputbox">
            <span>Entrez votre identifiant</span>
            <input type="text" name="id" id="id" placeholder="Entrez votre identifiant" required>
        </div>
        <div class="inputbox">
            <span>Entrez votre mot de passe</span>
            <input type="password" name="password" id="password" placeholder="Entrez votre mot de passe" required>
        </div>
        <footer>
            <input type="submit" value="Se Connecter">
        </footer>
        <?php
            if(isset($error) AND $error!=0)
            {
                echo "<div class=\"inputbox\" style=\"text-align: center; color: darkred;\">Identifiant ou mot de passe incorrect</div>
                ";
            }
        ?>
    </form>
</div>
</body>
<script>
    transite = ["transite","transite1","transite2","transite4"];
    tab=[<?php
        for($i=0;$i<sizeof($bestImages);$i++)
        {
            if($i<(sizeof($bestImages) - 1))
            {
                echo "\"".htmlspecialchars($bestImages[$i])."\",";
            }else
            {
                echo "\"".htmlspecialchars($bestImages[$i])."\"";
            }
        }
    ?>];
     img = document.getElementById("img");
     
    let i=1
    setInterval(()=>{
        img.src ="../Images/"+ tab[i%tab.length]
        img.setAttribute("style","animation: "+transite[i%transite.length]+" 2s;")
        i+=1
    },15000)


    secimg1=[
        <?php
            for($i=0;$i<sizeof($secimg1);$i++)
            {
                if($i<(sizeof($secimg1) - 1))
                {
                    echo "\"".htmlspecialchars($secimg1[$i])."\",";
                }else
                {
                    echo "\"".htmlspecialchars($secimg1[$i])."\"";
                }
            }
        ?>
    ]
    secimg2=[
        <?php
            for($i=0;$i<sizeof($secimg2);$i++)
            {
                if($i<(sizeof($secimg2) - 1))
                {
                    echo "\"".htmlspecialchars($secimg2[$i])."\",";
                }else
                {
                    echo "\"".htmlspecialchars($secimg2[$i])."\"";
                }
            }
        ?>
    ]

    secimg3=[
        <?php
            for($i=0;$i<sizeof($secimg3);$i++)
            {
                if($i<(sizeof($secimg3) - 1))
                {
                    echo "\"".htmlspecialchars($secimg3[$i])."\",";
                }else
                {
                    echo "\"".htmlspecialchars($secimg3[$i])."\"";
                }
            }
        ?>
    ]

    secimg4=[
        <?php
            for($i=0;$i<sizeof($secimg4);$i++)
            {
                if($i<(sizeof($secimg4) - 1))
                {
                    echo "\"".htmlspecialchars($secimg4[$i])."\",";
                }else
                {
                    echo "\"".htmlspecialchars($secimg4[$i])."\"";
                }
            }
        ?>
    ]

    secimg5=[
        <?php
            for($i=0;$i<sizeof($secimg5);$i++)
            {
                if($i<(sizeof($secimg5) - 1))
                {
                    echo "\"".htmlspecialchars($secimg5[$i])."\",";
                }else
                {
                    echo "\"".htmlspecialchars($secimg5[$i])."\"";
                }
            }
        ?>
    ]

    img1 = document.getElementById("secimg1");
     
    let a=1
    setInterval(()=>{
        img1.src ="../Images/"+ secimg1[a%secimg1.length]
        img1.setAttribute("style","animation: "+transite[a%transite.length]+" 2s;")
        a+=1
    },10000)

    img2 = document.getElementById("secimg2");
     
    let b=1
    setInterval(()=>{
        img2.src ="../Images/"+ secimg2[b%secimg2.length]
        img2.setAttribute("style","animation: "+transite[b%transite.length]+" 2s;")
        b+=1
    },10000)

    img3 = document.getElementById("secimg3");
     
    let c=1
    setInterval(()=>{
        img3.src ="../Images/"+ secimg3[c%secimg3.length]
        img3.setAttribute("style","animation: "+transite[c%transite.length]+" 2s;")
        c+=1
    },10000)

    img4 = document.getElementById("secimg4");
     
     let d=1
     setInterval(()=>{
         img4.src ="../Images/"+ secimg4[d%secimg4.length]
         img4.setAttribute("style","animation: "+transite[d%transite.length]+" 2s;")
         d+=1
     },10000)

     img5 = document.getElementById("secimg5");
     
     let e=1
     setInterval(()=>{
         img5.src ="../Images/"+ secimg5[e%secimg5.length]
         img5.setAttribute("style","animation: "+transite[e%transite.length]+" 2s;")
         e+=1
     },10000)











    function menu()
    {
        if(document.getElementById("menu").style.opacity==0 && document.getElementById("blocMenu").style.opacity==0 )
        {
            document.getElementById("menu").style.opacity=1;
            document.getElementById("blocMenu").style.opacity=1;
            document.getElementById("menu").style.visibility="visible";
            document.getElementById("blocMenu").style.visibility="visible";
            document.getElementById("menu").style.transition="1s ease";
            document.getElementById("blocMenu").style.transition="1s ease";
        }else
        {
            document.getElementById("menu").style.opacity=0;
            document.getElementById("blocMenu").style.opacity=0;
            document.getElementById("menu").style.visibility="hidden";
            document.getElementById("blocMenu").style.visibility="hidden";
            document.getElementById("menu").style.transition="1s ease";
            document.getElementById("blocMenu").style.transition="1s ease";
        }
    }
    function connexion()
    {
        if(document.getElementById("blocConnexion").style.visibility=="hidden" && document.getElementById("connexion").style.visibility=="hidden")
        {
            document.getElementById("connexion").style.visibility="visible";
            document.getElementById("blocConnexion").style.visibility="visible";
            document.getElementById("connexion").style.opacity=1;
            document.getElementById("blocConnexion").style.opacity=1;
            document.getElementById("connexion").style.transition="1s ease";
            document.getElementById("blocConnexion").style.transition="1s ease";
            
        }else
        {
            document.getElementById("connexion").style.visibility="hidden";
            document.getElementById("blocConnexion").style.visibility="hidden";
            document.getElementById("connexion").style.opacity=0;
            document.getElementById("blocConnexion").style.opacity=0;
            document.getElementById("connexion").style.transition="1s ease";
            document.getElementById("blocConnexion").style.transition="1s ease";
        }
    }
</script>
</html>