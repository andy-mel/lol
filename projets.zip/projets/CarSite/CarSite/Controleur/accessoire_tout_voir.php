<?php
    header("location:../Vue/vue_accessoire.php");

?>