<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
<meta charset="UTF-8">
<?php


require_once('../Modele/resultatRecherche.php');

$resultat = recherche(decesar8($_GET['motsCle']));

if(isset($_GET['page']) AND $_GET['page']=="gestion")
{
    $resultat = rechercheGestion(decesar8($_GET['motsCle']));
}
include_once('../Vue/resultatRecherche.php');

