<?php
    require_once("../Modele/article.php");
    if(isset($_GET['type'])){
        $type = $_GET['type'];
        switch ($type)
        {
            case "NOS ACCESSOIRES":
                $type = "accessoire";
                break;
            default:
                $type = "ordinateur";
                break;
        }
        if(isset($_POST['lien']))
        {
            $resultat = getArticle($type,$_POST['lien']);
        }else
        {
            $resultat = getArticle($type, "tout");
        }
    }
    else {
        # code...
        header("location: ../Controleur/accueil.php");
    }
    require_once("../Vue/article.php");
?>
