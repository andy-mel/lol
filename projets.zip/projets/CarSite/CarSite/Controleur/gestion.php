<?php
    require_once("../Modele/gestion.php");
        if(isset($_GET['id_article']))
        {
                $id = $_GET['id_article'];
                $donnees = get_modification($id);
                $description = $donnees['description'];
                $statut = $donnees["statut"];
                $etat = $donnees["etat"];
                $genre = $donnees["genre"];
                $nom = $donnees["nom"];
            if(isset($_POST['submit']))
            {
                update($_POST['nom'],$_POST['description'],$_POST['statut'],$_POST['etat'],$_POST['genre'],$_GET['id_article']);
                header('Location: presentation_article.php?id_article='.$_GET['id_article']);
            }
        }else
        {
                if(isset($_POST['lien']))
                {
                    $resultat = getArticle($_POST['lien']);
                }else
                {
                    $resultat = getArticle("tout");
                }
        }

    require_once("../Vue/gestion.php");
?>
