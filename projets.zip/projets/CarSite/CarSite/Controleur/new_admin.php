<?php
    require_once('../Modele/new_admin.php');
    $etape = 1;
    if(isset($_POST['pass'])){
        $password = $_POST['pass'];
        $etape = verify_password($password);
    }
    
    if(isset($_POST['id'],$_POST['password'])){
        $etape = 3;
        $id = $_POST['id'];
        $password = $_POST['password'];
    }
    if(isset($_POST['hidden_id'],$_POST['hidden_password'],$_POST['soumettre'])){
        if($_POST['soumettre'] == "back"){
            $etape = 2;
        }else{
        $id = $_POST['hidden_id'];
        $password = $_POST['hidden_password'];
        $etape = verify_id($id);
        if($etape == 4){
            add_admin($id,$password);
        }
    }
    /*<script>alert('bonjour')</script>*/
    }
    if(isset($_POST['submit'])){
        if($_POST['submit']== "back"){
            $etape = 2;
        }
        else{
            header("location: ../Controleur/accueil.php");
        }
    }
    require_once('../Vue/new_admin.php');
?>
