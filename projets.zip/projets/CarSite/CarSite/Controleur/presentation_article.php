<?php

    require_once('../Modele/presentation_article.php');

    if(isset($_GET['id_article']))
    {
        if(isset($_GET['delete']) AND $_GET['delete']=="true" AND isset($_GET['id_picture']))
        {
            delete($_GET['id_picture']);
            header('Location: presentation_article.php?id_article='.$_GET['id_article']);
        }
        if(isset($_FILES['fichier']) AND isset($_POST['id']))
        {
            $error = setFile($_FILES['fichier'],$_POST['id']);
            header('Location: presentation_article.php?id_article='.$_GET['id_article']);
        }
        if(isset($_POST['suppression']))
        {
            supprimer($_GET['id_article']);
            header('Location: ../Controleur/accueil.php?suppression=réussie');
        }
        $lastPicture = getLastPicture($_GET['id_article']);
        $infos = getElement($_GET['id_article']);
        $allPictures = getBestImages($_GET['id_article']);
        $pictures = getId($_GET['id_article']);
        
    }
    include_once('../Vue/Presentation_article.php');
?>