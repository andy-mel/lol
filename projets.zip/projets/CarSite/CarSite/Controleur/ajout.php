<?php

require_once('../Modele/ajout.php');

if(isset($_POST['type']) AND isset($_POST['etat']) AND isset($_POST['statut']))
{
    $etape = 1;
    $type = $_POST['type'];
    $etat = $_POST['etat'];
    $statut = $_POST['statut'];
}
if(isset($_POST['nom']) AND isset($_POST['description']))
{
        $etape = 2;
        $nom = $_POST['nom'];
        $description = $_POST['description'];
}
if(isset($_FILES['fichier']))
{
    $etape = 3;
}

if(isset($_POST['submit']) AND $_POST['submit']=="Précédent")
{
    $etape-=1;
}
if(isset($etape) AND $etape==3)
{
    setArticle($_POST['nom'],$_POST['description'],$_POST['type'],$_POST['etat'],$_POST['statut']);
    $error=setFile($_FILES['fichier']);
    header('Location: ../Controleur/accueil.php?erreur='.$error);
}
if(isset($_POST['submit']) AND $_POST['submit']=="Précédent")
{
    $etape-=2;
}
include_once('../Vue/ajout.php');

