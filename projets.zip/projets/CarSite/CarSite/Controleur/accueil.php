<?php

    require_once('../Modele/accueil.php');

    if(isset($_POST['password']) AND isset($_POST['id']))
    {
        $error=Verification($_POST['id'],$_POST['password']);
    }
    if(isset($_POST['deconnect']))
    {
        deconnect();
    }
    $best=getBest();
    $bestImages=getBestImages($best['id']);
    $section=getFive();
    $voiture=getVoiture($nomVoiture);
    $accessoire=getAccessoire($nomAccessoire);
    $secimg1=getBestImages($section[0]);
    $secimg2=getBestImages($section[1]);
    $secimg3=getBestImages($section[2]);
    $secimg4=getBestImages($section[3]);
    $secimg5=getBestImages($section[4]);
    include_once('../Vue/accueil.php');

?>