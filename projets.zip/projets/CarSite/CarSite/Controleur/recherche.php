<?php

require_once('../Modele/recherche.php');

if(isset($_POST['search']))
{
    if(isset($_GET['page']) AND $_GET['page'] == "gestion")
    {
        header('Location: resultatRecherche.php?page=gestion&motsCle='.cesar8($_POST['search']));
    }else
    {
    header('Location: resultatRecherche.php?motsCle='.cesar8($_POST['search']));
    }
}
$five = getFive();
include_once('../Vue/recherche.php');

?>