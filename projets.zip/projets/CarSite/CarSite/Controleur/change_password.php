<?php
    require_once('../Modele/change_password.php');
    $etape = 1;
    if(isset($_POST['pass'],$_POST['id'])){
        $password = $_POST['pass'];
        $id = $_POST['id'];
        $etape = verify($password,$id);
    }

    if(isset($_POST["type"],$_POST['id'])){
        $etape = 3;
        $type = $_POST['type'];
        $id = $_POST['id'];
    }
    //changer d'identifiant et mot de passe
    if(isset($_POST['submit'],$_POST['hidden'],$_POST['id'])){
        $type = $_POST['hidden'];
        $id = $_POST['id'];
        if($_POST["submit"] == "back"){
            $etape = 2;
        }
        else{
            if(isset($_POST['new_id1'],$_POST['new_id2'])){
                if($_POST['new_id1'] == $_POST['new_id2']){
                    $new_id = $_POST['new_id1'];
                    $error = id_exist($new_id);
                    if($error != "id_existant"){
                    change_id($new_id,$id);
                    $etape = 4;
                    }
                    else{
                        $etape = 3;
                    }

                }
                else{
                    $etape = 3;
                    $error = "password_different";
                }             
            }elseif(isset($_POST['new_password1'],$_POST['new_password2'])){
                if($_POST['new_password1'] == $_POST['new_password2']){
                    $new_password = $_POST['new_password1'];
                    change_password($new_password,$id);
                    $etape = 4;  
                }
                else{
                    $etape = 3;
                    $error = "password_different";
                }
            }           
        }

    }
    //terminer
    if(isset($_POST["soumettre"],$_POST['hidden'],$_POST['id'])){
        $id = $_POST['id'];
        if($_POST["soumettre"] == "back"){
            $etape = 3;
            $type = $_POST['hidden'];
        }
        else{
            header('location: ../Controleur/accueil.php');
        }
    }
    require_once('../Vue/change_password.php');
?>
