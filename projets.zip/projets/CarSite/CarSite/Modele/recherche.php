<?php

require_once('../Modele/connexion.php');

function getPosition($lettre,$mot)
{
    $i=0;
    do
    {
        if($lettre == $mot[$i])
        {
            break;
        }
        $i += 1;
    }while($i < strlen($mot));
    if($i >= strlen($mot))
    {
        return "false";
    }else
    {
        return $i;
    }
}

function cesar8($mots)
{
    $tab="1234567890azertyuiopqsdfghjklmwxcvbnAZERTYUIOPQSDFGHJKLMWXCVBN ";
    $newWord = "";
    $interdit = "&£§¤µ¨²";
    for($i = 0 ; $i < strlen($mots); $i++)
    {
        $pos = getPosition($mots[$i],$tab);
        if($pos != "false")
        {
            $pos+=8;
            $pos%=strlen($tab);
            $newWord.=$tab[$pos];
        }else
        {
            $newWord.=$mots[$i];
        }
    }
    return $newWord;
}

function getFive()
{
    global $bdd;
    $req = $bdd -> query('SELECT `nom` FROM `article` WHERE `statut` = \'present\' ORDER BY `nbre` DESC LIMIT 0,5');
    $i = 0;
    while($donnees = $req -> fetch())
    {
        $tab[$i] = $donnees['nom'];
        $i += 1;
    }

    return $tab;
}

