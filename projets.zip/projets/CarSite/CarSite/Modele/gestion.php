<?php
include_once('../Modele/connexion.php');
session_start();

    function setArticle(){
        require_once('../Modele/connexion.php');
        $req = "SELECT photo.id_article as id_article,photo.name as name,photo.type as type,article.nom as nom,article.description as description from photo,article where photo.id_article=article.id and article.statut='absent' group by(article.id)";
        $resultat = $bdd->prepare($req);
        $resultat->execute(array());
        $donnees = $resultat->fetchAll();
        return $donnees;
    }

    function setArticle_search($search){
        require_once('../Modele/connexion.php');
        $search = "%".$search."%";
        $req = "SELECT photo.id_article as id_article,photo.name as name,photo.type as type,article.nom as nom,article.description as description from photo,article where photo.id_article=article.id and article.satut='absent' (article.nom LIKE ? OR article.description LIKE ?) group by(article.id)";
        $resultat = $bdd->prepare($req);
        $resultat->execute(array($search,$search));
        $donnees = $resultat->fetchAll();
        return $donnees;
    }
    function affichage($donnees){
        if(sizeof($donnees) == 0){
            echo "<center><h1>desole mais nous ne trouvons pas d'element correspondant a votre recherche</h1></center>";
        }else{
        foreach($donnees as $ligne){
        echo "
        <div>
        <div class='section'>
        <div class='img'><img src='../Images/".$ligne['name']."".$ligne['type']."' alt='images'>
        </div>
        <div class='detail'>
            <p class='nom'>   
            ".$ligne['nom']."
            </p>
            <p class='description'>
            ".$ligne['description']."
            </p>
            
        </div>
        </div>
        <div class='radio'><input type='radio' name='id' value='".$ligne['id_article']."' checked></div>
        <hr>        
        </div>

        ";            
        }            
        }


    }
    function get_modification($id){
        require('../Modele/connexion.php');
        $req = $bdd->prepare("SELECT description,statut,etat,nom,genre from article where id=?");
        $req->execute(array($id));
        $donnees = $req->fetch();
        return $donnees;

    }
   function update($nom, $description, $statut, $etat, $genre,$id)
   {
    global $bdd;
    $req = $bdd -> prepare('UPDATE `article` SET `nom` = ?, `description` = ?, `statut` = ?, `etat` = ?, `genre` = ? WHERE `id` = ?');
    $req -> execute(array($nom, $description, $statut, $etat, $genre, $id));
   }
   function getArticle( $lien)
{
    global $bdd;
    if($lien == "tout"){
        $req = $bdd -> query('SELECT `id` FROM `article` WHERE `statut` = \'absent\' ORDER BY `dateAjout` DESC');
    }else
    {
        $req = $bdd -> prepare('SELECT `id` FROM `article` WHERE (`statut` = \'absent\' AND `etat` = ?) ORDER BY `dateAjout` DESC');
        $req -> execute(array($lien));
    }
    $i = 0;
    $tab = array();
    while($donnees = $req -> fetch())
    {
        $tab[$i] = $donnees['id'];
        $i+=1;
    }
    return $tab;
}

function getElement($id)
{
    global $bdd;
    $req = $bdd -> prepare('SELECT * FROM `article` WHERE `id` = ? ');
    $req -> execute(array($id));
    $req = $req -> fetch();
    return $req;
}

function getLastPicture($id)
{
    global $bdd;
    $req = $bdd -> prepare('SELECT `name` , `type` FROM `photo` WHERE `id_article` = ? ORDER BY `date_ajout` DESC LIMIT 0,1');
    $req -> execute(array($id));
    $donnees = $req -> fetch();
    $nom = $donnees['name']."".$donnees['type'];
    $nom = "../Images/".$nom;
    return $nom;
}

?>
