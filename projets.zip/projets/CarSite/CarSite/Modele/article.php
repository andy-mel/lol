<?php

require_once('../Modele/connexion.php');
session_start();

function getArticle($type, $lien)
{
    global $bdd;
    if($lien == "tout"){
        $req = $bdd -> prepare('SELECT `id` FROM `article` WHERE `statut` = \'present\' AND `genre` = ? ORDER BY `dateAjout` DESC');
        $req -> execute(array($type));
    }else
    {
        $req = $bdd -> prepare('SELECT `id` FROM `article` WHERE (`statut` = \'present\' AND `genre` = ? AND `etat` = ?) ORDER BY `dateAjout` DESC');
        $req -> execute(array($type, $lien));
    }
    $i = 0;
    $tab = array();
    while($donnees = $req -> fetch())
    {
        $tab[$i] = $donnees['id'];
        $i+=1;
    }
    return $tab;
}

function getElement($id)
{
    global $bdd;
    $req = $bdd -> prepare('SELECT * FROM `article` WHERE `id` = ? ');
    $req -> execute(array($id));
    $req = $req -> fetch();
    return $req;
}

function getLastPicture($id)
{
    global $bdd;
    $req = $bdd -> prepare('SELECT `name` , `type` FROM `photo` WHERE `id_article` = ? ORDER BY `date_ajout` DESC LIMIT 0,1');
    $req -> execute(array($id));
    $donnees = $req -> fetch();
    $nom = $donnees['name']."".$donnees['type'];
    $nom = "../Images/".$nom;
    return $nom;
}

