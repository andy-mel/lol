<?php

    function images_accessoires(){
        require_once('../Modele/connexion.php');
        $req = "select photo.id_article as id_article,photo.name as name,photo.type as type,article.nom as nom,article.description as description from photo,article where article.genre='accessoire' and  photo.id_article=article.id group by(article.id)";
        $resultat = $bdd->query($req);
        $donnees = $resultat->fetchAll();
        return $donnees;
    }
?>