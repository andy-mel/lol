<?php

require_once('../Modele/connexion.php');
session_start();
function getPosition($lettre,$mot)
{
    $i=0;
    do
    {
        if($lettre == $mot[$i])
        {
            break;
        }
        $i += 1;
    }while($i < strlen($mot));
    if($i >= strlen($mot))
    {
        return "false";
    }else
    {
        return $i;
    }
}

function decesar8($mots)
{
    $tab="1234567890azertyuiopqsdfghjklmwxcvbnAZERTYUIOPQSDFGHJKLMWXCVBN ";
    $newWord = "";
    for($i = 0 ; $i < strlen($mots); $i++)
    {
        $pos = getPosition($mots[$i],$tab);
        if($pos == "false")
        {
            $newWord.=$mots[$i];
        }else
        {
            $pos-=8;
            if($pos < 0)
            {
                $pos += strlen($tab);
            }
            $newWord.=$tab[$pos];
        }
        
    }
    return $newWord;
}

function getSpace($mots)
{
    $nbre = 0;
    for( $i = 0 ; $i < strlen($mots) ; $i++)
    {
        if($mots[$i] == " ")
        {
            $nbre += 1 ;
        }
    }
    return $nbre;
}

function search($motsCle)
{
    global $bdd;
    $req = $bdd -> prepare('SELECT `id` FROM `article` WHERE ((`nom` LIKE ? AND `description` LIKE ?)  AND `statut` = \'present\') ORDER BY `dateAjout` DESC');
    $motsCle = "%".$motsCle."%";
    $req -> execute(array($motsCle, $motsCle));
    $i = 0;
    $tab = array();
    while($donnees = $req -> fetch())
    {
        $tab[$i] = $donnees['id'];
        $i++;
    }
    $req = $bdd -> prepare('SELECT `id` FROM `article` WHERE (`statut` = \'present\' AND (`nom` LIKE ? OR `description` LIKE ?)) ORDER BY `dateAjout` DESC');
    $motsCle = "%".$motsCle."%";
    $req -> execute(array($motsCle, $motsCle));
    while($donnees = $req -> fetch())
    {
        $tab[$i] = $donnees['id'];
        $i++;
    }
    return $tab;
}

function searchGestion($motsCle)
{
    global $bdd;
    $req = $bdd -> prepare('SELECT `id` FROM `article` WHERE ((`nom` LIKE ? AND `description` LIKE ?)  AND `statut` = \'absent\') ORDER BY `dateAjout` DESC');
    $motsCle = "%".$motsCle."%";
    $req -> execute(array($motsCle, $motsCle));
    $i = 0;
    $tab = array();
    while($donnees = $req -> fetch())
    {
        $tab[$i] = $donnees['id'];
        $i++;
    }
    $req = $bdd -> prepare('SELECT `id` FROM `article` WHERE (`statut` = \'absent\' AND (`nom` LIKE ? OR `description` LIKE ?)) ORDER BY `dateAjout` DESC');
    $motsCle = "%".$motsCle."%";
    $req -> execute(array($motsCle, $motsCle));
    while($donnees = $req -> fetch())
    {
        $tab[$i] = $donnees['id'];
        $i++;
    }
    return $tab;
}

function getPositionSpace($mot,$nbre)
{
    $space = 0;
    for($i = 0 ; $i <= strlen($mot) and $space < $nbre ; $i++)
    {
        if($mot[$i] == " ")
        {
            $space += 1;
        }
    }
     return $i;
}

function getWord($mot, $nbre1, $nbre2)
{
    $word = "";
    for( $i = $nbre1 ; $i < $nbre2-1 ; $i++)
    {
        $word .= $mot[$i];
    }
    return $word;
}

function update($id,$nbre)
{
    global $bdd;
    $req = $bdd -> prepare('SELECT `nbre` FROM `article` WHERE `id` = ? ');
    $req -> execute(array($id));
    $don = $req -> fetch();
    $donnees = $don['nbre'] + $nbre;
    $req = $bdd -> prepare('UPDATE `article` SET `nbre` = ? WHERE `id` = ?');
    $req -> execute(array($donnees,$id));
}

function recherche($motsCle)
{
    $motsCle = trim($motsCle);
    $nbreSpace = getSpace($motsCle);
    $k = 0;
    $compteur = 0;
    $tab = array();
    if($nbreSpace >= 2)
    {
        while($compteur < $nbreSpace-1)
        {
            if($compteur == $nbreSpace-2)
            {
            $tab[$k] = getWord($motsCle, getPositionSpace($motsCle,$compteur), strlen($motsCle)+1);
            $compteur++;
            $k++;
            }else
            {
            $tab[$k] = getWord($motsCle, getPositionSpace($motsCle,$compteur), getPositionSpace($motsCle,$compteur + 3));
            $compteur++;
            $k++;
            }
            
        }
    }
    $compteur = 0;
    if($nbreSpace >=1)
    {
        while($compteur < $nbreSpace)
        {
            if($compteur == $nbreSpace-1)
            {
            $tab[$k] = getWord($motsCle, getPositionSpace($motsCle,$compteur), strlen($motsCle)+1);
            $compteur++;
            $k++;
            }else
            {
            $tab[$k] = getWord($motsCle, getPositionSpace($motsCle,$compteur), getPositionSpace($motsCle,$compteur + 2));
            $compteur++;
            $k++;
            }
        }
    }
    $compteur = 0;
    if($nbreSpace >= 0)
    {
        while($compteur <= $nbreSpace)
        {
            if($compteur == $nbreSpace)
            {
            $tab[$k] = getWord($motsCle, getPositionSpace($motsCle,$compteur), strlen($motsCle)+1);
            $compteur++;
            $k++;
            }else
            {
            $tab[$k] = getWord($motsCle, getPositionSpace($motsCle,$compteur), getPositionSpace($motsCle,$compteur + 1));
            $compteur++;
            $k++;
            }
        }
    }
    $resultat = search($motsCle);
    for( $i = 0 ; $i < sizeof($tab) ; $i++)
    {
        $tmp = array_merge($resultat, search($tab[$i]));
        $resultat = $tmp;
    }

    $compteur = sizeof($resultat);

    for($i = 0 ; $i < $compteur ; $i++)
    {
        for($j = $i + 1; $j < $compteur ; $j++)
        {
            if($resultat[$i] == $resultat[$j])
            {
                array_splice($resultat, $j , 1);
                $compteur --;
                $j--;
            }
        }
    }
    $nb = sizeof($resultat);
    for($i = 0 ; $i < sizeof($resultat) ; $i++)
    {
        update($resultat[$i],$nb);
        $nb--;
    }
    return $resultat;
}

function getElement($id)
{
    global $bdd;
    $req = $bdd -> prepare('SELECT * FROM `article` WHERE `id` = ? ');
    $req -> execute(array($id));
    $req = $req -> fetch();
    return $req;
}

function getLastPicture($id)
{
    global $bdd;
    $req = $bdd -> prepare('SELECT `name` , `type` FROM `photo` WHERE `id_article` = ? ORDER BY `date_ajout` DESC LIMIT 0,1');
    $req -> execute(array($id));
    $donnees = $req -> fetch();
    $nom = $donnees['name']."".$donnees['type'];
    $nom = "../Images/".$nom;
    return $nom;
}

function rechercheGestion($motsCle)
{
    $motsCle = trim($motsCle);
    $nbreSpace = getSpace($motsCle);
    $k = 0;
    $compteur = 0;
    $tab = array();
    if($nbreSpace >= 2)
    {
        while($compteur < $nbreSpace-1)
        {
            if($compteur == $nbreSpace-2)
            {
            $tab[$k] = getWord($motsCle, getPositionSpace($motsCle,$compteur), strlen($motsCle)+1);
            $compteur++;
            $k++;
            }else
            {
            $tab[$k] = getWord($motsCle, getPositionSpace($motsCle,$compteur), getPositionSpace($motsCle,$compteur + 3));
            $compteur++;
            $k++;
            }
            
        }
    }
    $compteur = 0;
    if($nbreSpace >=1)
    {
        while($compteur < $nbreSpace)
        {
            if($compteur == $nbreSpace-1)
            {
            $tab[$k] = getWord($motsCle, getPositionSpace($motsCle,$compteur), strlen($motsCle)+1);
            $compteur++;
            $k++;
            }else
            {
            $tab[$k] = getWord($motsCle, getPositionSpace($motsCle,$compteur), getPositionSpace($motsCle,$compteur + 2));
            $compteur++;
            $k++;
            }
        }
    }
    $compteur = 0;
    if($nbreSpace >= 0)
    {
        while($compteur <= $nbreSpace)
        {
            if($compteur == $nbreSpace)
            {
            $tab[$k] = getWord($motsCle, getPositionSpace($motsCle,$compteur), strlen($motsCle)+1);
            $compteur++;
            $k++;
            }else
            {
            $tab[$k] = getWord($motsCle, getPositionSpace($motsCle,$compteur), getPositionSpace($motsCle,$compteur + 1));
            $compteur++;
            $k++;
            }
        }
    }
    $resultat = searchGestion($motsCle);
    for( $i = 0 ; $i < sizeof($tab) ; $i++)
    {
        $tmp = array_merge($resultat, searchGestion($tab[$i]));
        $resultat = $tmp;
    }

    $compteur = sizeof($resultat);

    for($i = 0 ; $i < $compteur ; $i++)
    {
        for($j = $i + 1; $j < $compteur ; $j++)
        {
            if($resultat[$i] == $resultat[$j])
            {
                array_splice($resultat, $j , 1);
                $compteur --;
                $j--;
            }
        }
    }
    $nb = sizeof($resultat);
    for($i = 0 ; $i < sizeof($resultat) ; $i++)
    {
        update($resultat[$i],$nb);
        $nb--;
    }
    return $resultat;
}


