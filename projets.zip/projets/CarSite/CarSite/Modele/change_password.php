<?php
    function verify($password,$id){
        global $error;
        require('../Modele/connexion.php');
        $req = $bdd->prepare("SELECT password from users  where id=? AND password=? limit 0,1");
        $req->execute(array($id,$password));
        $donnees = $req->fetch();
        if($donnees != ""){
            $etape = 2;
        }
        else{
            $etape = 1;
            $error = 'password_false';
        }
        return $etape;
    }
    function change_password($new,$id){
        require('../Modele/connexion.php');
        $req = $bdd->prepare("UPDATE users set password=? where id=?");
        $req->execute(array($new,$id));
    }
    function change_id($new,$id){
        require('../Modele/connexion.php');
        $req = $bdd->prepare("UPDATE users set id=? where id=?");
        $req->execute(array($new,$id));
    }
    function id_exist($id){
        global $error;
        $error = "";
        require('../Modele/connexion.php');
        $req = $bdd->prepare("SELECT id from users WHERE id=?");
        $req->execute(array($id));
        $donnees = $req->fetch();
        if($donnees != ""){
            $error = "id_existant";
        }
        return $error;
    }
?>