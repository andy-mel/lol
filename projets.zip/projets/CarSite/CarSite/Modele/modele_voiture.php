<?php
    function images_voitures(){
        require_once('../Modele/connexion.php');
        $req = "select photo.id_article as id_article,photo.name as name,photo.type as type,article.nom as nom,article.description as description from photo,article where article.genre='voiture' and  photo.id_article=article.id group by(article.id)";
        $resultat = $bdd->query($req);
        $donnees = $resultat->fetchAll();
        return $donnees;
    }
    function affichage($donnees){
        foreach($donnees as $ligne){
        echo "
        <div class='section'>
        <div class='img'><a href='../Vue/presentation_article.php?id_article=".$ligne['id_article']."'><img src='../Images/".$ligne['name']."".$ligne['type']."' alt='images'>
            </a>
        </div>
        <div class='detail'>
            <p class='nom'>   
            ".$ligne['nom']."
            </p>
            <p class='description'>
            ".$ligne['description']."
            </p>
        </div>
        </div>
        <hr>
        ";            
        }

    }
?>

