<?php

require_once('../Modele/connexion.php');
session_start();

function setArticle($nom, $description, $type, $etat, $statut)
{
    global $bdd;
    $req=$bdd->prepare('INSERT INTO `article`(`id`,`nom`,`description`,`genre`,`dateAjout`,`nbre`,`etat`,`statut`) VALUES (\'\',?,?,?,NOW(),?,?,?)');
    $req->execute(array($nom,$description,$type,0,$etat,$statut));
}

function setFile($fichier)
{
    $fileName=$fichier['name'];
    $fileTmpName=$fichier['tmp_name'];
    $fileSize=$fichier['size'];
    $fileError = $fichier['error'];

    if($fileError === 0)
    {
        if($fileSize < (8*1024*1024))
        {
            $fileDestination="../Images/".$fileName;
            move_uploaded_file($fileTmpName,$fileDestination);
            $extension = pathinfo($fileName, PATHINFO_EXTENSION);
            $extension = ".".$extension;
            global $bdd;
            $req=$bdd->query('SELECT `id` FROM `article` ORDER BY `dateAjout` DESC LIMIT 0,1');
            $req = $req->fetch();
            $id_article = $req['id'];

            $req = $bdd -> query('SELECT MAX(`id`) AS `nom` FROM `photo`');
            $req = $req -> fetch();
            $name = intval($req['nom']) + 1;

            $req = $bdd -> prepare('INSERT INTO `photo`(`id`,`id_article`,`name`,`type`,`date_ajout`) VALUES (\'\',?,?,?,NOW())');
            $req -> execute(array($id_article,$name,$extension));

            $newFileName = "../Images/".$name."".$extension;

            rename($fileDestination,$newFileName);

        }else
        {
            return "Le fichier est trop volumineux";
        }
    }else
    {
        return $fileError;
    }
}
?>
