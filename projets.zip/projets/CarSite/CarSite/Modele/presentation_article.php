<?php
    session_start();
    require_once('../Modele/connexion.php');

    function getLastPicture($id)
    {
        global $bdd;
        $req = $bdd -> prepare('SELECT `name` , `type` FROM `photo` WHERE `id_article` = ? ORDER BY `date_ajout` DESC LIMIT 0,1');
        $req -> execute(array($id));
        $donnees = $req -> fetch();
        $nom = $donnees['name']."".$donnees['type'];
        $nom = "../Images/".$nom;
        return $nom;
    }

    function getElement($id)
    {
        global $bdd;
        $req = $bdd -> prepare('SELECT * FROM `article` WHERE `id` = ? ');
        $req -> execute(array($id));
        $req = $req -> fetch();
        return $req;
    }

    function getBestImages($id_article)
    {
        global $bdd;
        $req=$bdd->prepare('SELECT * FROM `photo` WHERE `id_article` = ? ORDER BY `date_ajout` DESC');
        $req->execute(array($id_article));
        $i=0;
        while($donnees = $req -> fetch())
        {
            $tab[$i]="../Images/".$donnees['name']."".$donnees['type'];
            $i+=1;
        }
        return $tab;
    }
    function getId($id_article)
    {
        global $bdd;
        $req=$bdd->prepare('SELECT `id` FROM `photo` WHERE `id_article` = ? ORDER BY `date_ajout` DESC');
        $req->execute(array($id_article));
        $i=0;
        while($donnees = $req -> fetch())
        {
            $tab[$i]=$donnees['id'];
            $i+=1;
        }
        return $tab;
    }
    function setFile($fichier, $id)
{
    $fileName=$fichier['name'];
    $fileTmpName=$fichier['tmp_name'];
    $fileSize=$fichier['size'];
    $fileError = $fichier['error'];

    if($fileError === 0)
    {
        if($fileSize < (8*1024*1024))
        {
            $fileDestination="../Images/".$fileName;
            move_uploaded_file($fileTmpName,$fileDestination);
            $extension = pathinfo($fileName, PATHINFO_EXTENSION);
            $extension = ".".$extension;
            global $bdd;
            $req=$bdd->prepare('SELECT `id` FROM `article` WHERE `id`=?');
            $req -> execute(array($id));
            $req = $req->fetch();
            $id_article = $req['id'];

            $req = $bdd -> query('SELECT MAX(`id`) AS `nom` FROM `photo`');
            $req = $req -> fetch();
            $name = intval($req['nom']) + 1;

            $req = $bdd -> prepare('INSERT INTO `photo`(`id`,`id_article`,`name`,`type`,`date_ajout`) VALUES (\'\',?,?,?,NOW())');
            $req -> execute(array($id_article,$name,$extension));

            $newFileName = "../Images/".$name."".$extension;

            rename($fileDestination,$newFileName);

        }else
        {
            return "Le fichier est trop volumineux";
        }
    }else
    {
        return $fileError;
    }
}

    function delete($id)
    {
        global $bdd;
        $req = $bdd -> prepare('SELECT `name`,`type`,`id_article` FROM `photo` WHERE `id` = ? ');
        $req -> execute(array($id));
        $name = $req -> fetch();
        $req = $bdd -> prepare('SELECT COUNT(`id`) AS `nbre` FROM `photo` WHERE `id_article` = ? ');
        $req -> execute(array($name['id_article']));
        $nbre = $req -> fetch();
        if($nbre['nbre']>1)
        {
        $name = "../Images/" . $name['name'] . "" . $name['type'];
        unlink($name);
        $req = $bdd -> prepare('DELETE FROM `photo` WHERE `id` = ?');
        $req -> execute(array($id));
        }
    }

    function supprimer($id)
    {
        global $bdd;

        // Suppression des fichiers

        $req = $bdd -> prepare('SELECT `name`,`type` FROM `photo` WHERE `id_article` = ? ');
        $req -> execute(array($id));
        while($donnees = $req -> fetch())
        {
            $name = "../Images/" . $donnees['name'] . "" . $donnees['type'];
            unlink($name);
        }

        // Vidage de la table `photo`

        $req = $bdd -> prepare('DELETE FROM `photo` WHERE `id_article` = ?');
        $req -> execute(array($id));

        // Suppresion de l'élément dans la table `article`

        $req = $bdd -> prepare('DELETE FROM `article` WHERE `id` = ?');
        $req -> execute(array($id)); 

    }
?>


