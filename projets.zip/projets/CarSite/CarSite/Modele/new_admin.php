<?php
    function verify_password($password){
        global $error;
        require('../Modele/connexion.php');
        $req = $bdd->prepare("SELECT password from users limit 0,1");
        $req->execute();
        $donnees = $req->fetch();
        if($password == $donnees['password']){
            $etape = 2;
        }
        else{
            $etape = 1;
            $error = 'password_false';
        }
        return $etape;
    }
    function verify_id($id){
        global $error;
        require('../Modele/connexion.php');
        $req = $bdd->prepare("SELECT id FROM users where id=? LIMIT 0,1 ");
        $req->execute(array($id));
        $donnees = $req->fetch();
        if($donnees != ""){
            $error = 'id_existant';
            $etape = 2;  
        }
        else{
            $etape = 4;
        }
        return $etape;
    }
    function add_admin($id,$password){
        require('../Modele/connexion.php');
        $req = $bdd->prepare("INSERT INTO users (id, password) VALUES (?,?)");
        $req->execute(array($id,$password));
    }
?>
