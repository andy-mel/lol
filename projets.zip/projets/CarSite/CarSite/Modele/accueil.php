<?php
require_once('../Modele/connexion.php');
session_start();
function getBest()
{
    global $bdd;
    $req=$bdd->query('SELECT * FROM `article` WHERE `statut` = \'present\' ORDER BY `nbre` DESC LIMIT 0,1');
    $donnees=$req->fetch();
    return $donnees;
}

function getBestImages($id_article)
{
    global $bdd;
    $req=$bdd->prepare('SELECT * FROM `photo` WHERE `id_article` = ? ORDER BY `date_ajout` DESC');
    $req->execute(array($id_article));
    $i=0;
    while($donnees = $req -> fetch())
    {
        $tab[$i]=$donnees['name']."".$donnees['type'];
        $i+=1;
    }
    return $tab;
}

function getFive()
{
    global $bdd;
    $req=$bdd->query('SELECT `id` FROM `article` WHERE `statut` = \'present\' ORDER BY `dateAjout` DESC LIMIT 0,5');
    $i=0;
    while($donnees= $req->fetch())
    {
        $tab[$i]=$donnees['id'];
        $i+=1;
    }
    return $tab;
}

function getName($id)
{
    global $bdd;
    $req=$bdd->prepare('SELECT `nom` FROM `article` WHERE  `statut` = \'present\' AND `id`=?');
    $req->execute(array($id));
    $donnees=$req->fetch();
    return $donnees['nom'];
}

function getImage($id)
{
    global $bdd;
    $req=$bdd->prepare('SELECT `name`,`type` FROM `photo` WHERE `id_article`=? ORDER BY `date_ajout` DESC LIMIT 0,1');
    $req->execute(array($id));
    $donnees=$req->fetch();
    $nom=$donnees['name']."".$donnees['type'];
    return $nom;
}

function getVoiture(&$nom)
{
    global $bdd;
    $req=$bdd->query("SELECT `id`,`nom` FROM `article` WHERE `statut` = 'present' AND `genre`='ordinateur' ORDER BY `dateAjout` DESC LIMIT 0,1");
    $donnees=$req->fetch();
    $nom=$donnees['nom'];
    return getImage($donnees['id']);
}

function getAccessoire(&$nom)
{
    global $bdd;
    $req=$bdd->query("SELECT `id`,`nom` FROM `article` WHERE `statut` = 'present' AND `genre`='accessoire' ORDER BY `dateAjout` DESC LIMIT 0,1");
    $donnees=$req->fetch();
    $nom=$donnees['nom'];
    return getImage($donnees['id']);
}

function Verification($id, $password)
{
    global $bdd;

    $req= $bdd->prepare('SELECT COUNT(`id`) AS `nbreUsers` FROM `users` WHERE (`id`=? AND `password`=?)');
    $req->execute(array($id,$password));
    $nbre=$req->fetch();
    $nbre=$nbre['nbreUsers'];
    if($nbre==1)
    {        
        $error=0;
        $_SESSION['admin']=1;
    }else
    {
        return $error=base64_encode("error");
    }
}

function deconnect()
{
    $_SESSION['admin']=0;
}

?>
