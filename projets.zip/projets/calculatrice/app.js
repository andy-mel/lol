let currentInput = '';
let previousInput = '';
let operator = null;

// Afficher l'input courant
function updateDisplay() {
    document.getElementById('display').value = currentInput;
}

// Ajouter un chiffre à l'écran
function appendNumber(number) {
    currentInput += number;
    updateDisplay();
}

// Choisir un opérateur
function chooseOperation(op) {
    if (currentInput === '') return; // Empêcher l'opération si aucun chiffre n'est entré
    if (previousInput !== '') {
        compute(); // Effectuer le calcul s'il y a déjà une opération en cours
    }
    operator = op;
    previousInput = currentInput;
    currentInput = '';
}

// Effectuer le calcul
function compute() {
    let result;
    const prev = parseFloat(previousInput);
    const current = parseFloat(currentInput);

    if (isNaN(prev) || isNaN(current)) return;

    switch (operator) {
        case '+':
            result = prev + current;
            break;
        case '-':
            result = prev - current;
            break;
        case '*':
            result = prev * current;
            break;
        case '/':
            if (current === 0) {
                result = 'Erreur';
                break;
            }
            result = prev / current;
            break;
        default:
            return;
    }

    currentInput = result.toString();
    operator = null;
    previousInput = '';
    updateDisplay();
}

// Effacer l'écran
function clearDisplay() {
    currentInput = '';
    previousInput = '';
    operator = null;
    updateDisplay();
}
