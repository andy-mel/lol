// Fonction pour mettre à jour l'heure
function updateClock() {
    const clockElement = document.getElementById('clock');
    const now = new Date();

    let hours = now.getHours();
    let minutes = now.getMinutes();
    let seconds = now.getSeconds();

    // Ajouter un 0 devant les chiffres inférieurs à 10
    hours = hours < 10 ? '0' + hours : hours;
    minutes = minutes < 10 ? '0' + minutes : minutes;
    seconds = seconds < 10 ? '0' + seconds : seconds;

    // Affichage de l'heure
    clockElement.textContent = `${hours}:${minutes}:${seconds}`;
}

// Mettre à jour l'heure toutes les secondes
setInterval(updateClock, 1000);

// Appel initial pour afficher l'heure immédiatement
updateClock();
